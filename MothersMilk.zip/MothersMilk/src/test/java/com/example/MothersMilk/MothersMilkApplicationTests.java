package com.example.MothersMilk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MothersMilkApplicationTests {

	@Test
	void contextLoads() {
	}

}
