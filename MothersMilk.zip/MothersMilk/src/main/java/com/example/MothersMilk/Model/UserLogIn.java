package com.example.MothersMilk.Model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "MothersGift.Sign_UP")
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class UserLogIn {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer userId;
    @Column(name = "account_type")
    @NotBlank(message = "Enter Account Type")
    private String accountType;
    @Column(name = "user_name")
    @NotBlank(message = "Enter User Name")
    private String userName;
    @Column(name = "password")
    @NotBlank(message = "Enter Password")
    private String password;
    @CreationTimestamp
    @Column(name = "created_at")
    private Timestamp createdAt;
    @Column(name = "created_by")
    private String createdBy;
}